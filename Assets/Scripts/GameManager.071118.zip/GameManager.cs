﻿ using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {
	public static GameManager instance;
	public Stack<string> activity;
	private bool settingUpBoard;
	public bool tilePlacementDebug;

	public GameObject[,] tiles;
	public Stack<GameObject> tileDrawPile;
	private List<Coord> availableMoves = new List<Coord>();
	private List<Coord> thisMove = new List<Coord>();

	[Header("Tiles")]
	public List<GameObject> startingTilePile;
	public GameObject[] permanentTiles;
	public int entranceStartingX;
	public int entranceStartingZ;
	public int upstairsStartingX;
	public int upstairsStartingZ;
	public int basementStartingX;
	public int basementStartingZ;
	public float tilesStart;
	public float tileHeight;

	[Header("Camera")]
	public Camera cam;
	public float cameraSpeed;
	public float cameraHeight;
	/// <summary>
	/// Use 90 for straight vertical
	/// </summary>
	public float cameraPitchAngle;
	/// <summary>
	/// Set 0 for straight North/South
	/// </summary>
	public float cameraYawAngle;
	public float cameraOffset;

	[Header("Placement Tile")]
	private RaycastHit rcHit;
	private int curX;
	private int curZ;
	private int oldX;
	private int oldZ;
	private Ray ray;
	public GameObject tmpTile;
	private int orientation;
	private bool tmpTileChangeMade;
	public float transparentAlpha;
	public float floatingHeight;

	[Header("HUD")]
	//public Image UITilePreview;
	public RawImage TilePreview;
	public Toggle usableUpstairs;
	public Toggle usableOnGroundFloor;
	public Toggle usableInBasement;
	public Toggle doorNorth;
	public Toggle doorEast;
	public Toggle doorSouth;
	public Toggle doorWest;

	public bool debugging = false;

	[Header("Outlines")]
	public GameObject outline;
	public float highlightY;
	private List<GameObject> outlines = new List<GameObject>();
	private bool outlinesSet;

	[Header("Players")]
	public GameObject[] availablePlayers;	// Holds available players that can be chosen.
	public GameObject[] players;            // Current players are saved here.
	private int currentPlayer;

	public class Coord
	{
		public int x;
		public int z;
		public Coord(int _x, int _z)
		{
			x = _x;
			z = _z;
		}
	}

	[Header("Ro Stuff")]
	/*=========== RO VARIABLES ===========*/
	public GameObject player; 																	//the player piece that will immediately instantiated when the game loads
	public Vector3 playerPos; 																	//this gets the current player's position on the board
	public Vector3 tilePos; 																	//this gets the current tile's position on the board
	public Vector3 targetPosition; 																//Determines the location of where the object will move
	public static List<Vector3> tilesToMove = new List<Vector3>(); 								//this puts the locations of green highlighted tiles in a list to make sure the player can move there
	Dictionary<Tile, Vector3> move = new Dictionary<Tile, Vector3>(); 

	/*=========== CLASS TO PASS VARIABLES TO PlayerTileHighlight SCRIPT ===========*/
	public class Highlight{
		public static bool highlightAvailableTiles;												//lets us know if we can highlight the specified tiles
		public static Dictionary<Tile, Vector3> tileDict = new Dictionary<Tile, Vector3>(); 	//stores every tile that is placed
		public static List<Tile> tilesToHighlight = new List<Tile>(); 							//sends over a list of tile objects to highlight
		public static List<Tile> tilesToNotHighlight = new List<Tile>(); 						//sends over a list of tile objects to highlight
		public static List<Tile> highlightYellow = new List<Tile>(); 	

	}

	/// <summary>
	/// Use this for initialization
	/// </summary>
	void Awake () {
		settingUpBoard = true;
		tiles = new GameObject[100, 100];
		//tilesForMovement = new GameObject[100, 100];
		if (instance == null)
		{
			DontDestroyOnLoad(gameObject);
			instance = this;
		} else if (instance != this)
		{
			Destroy(gameObject);
		}
		activity = new Stack<string>();
		SetActivity("placing tile");
		SetActivity("moving player");
	}
	/// <summary>
	/// Load starting tiles. Set initial camera position. Create the draw pile.
	/// </summary>
	private void Start()
	{
		
		// Load our Entrance
		PlaceTile(entranceStartingX, entranceStartingZ, permanentTiles[0]);											// Grand staircase
		PlaceTile(entranceStartingX, entranceStartingZ - 1, permanentTiles[1]);										// Foyer
		PlaceTile(entranceStartingX, entranceStartingZ - 2, permanentTiles[2]);										// Entrance Hall
		PlaceTile(entranceStartingX, entranceStartingZ - 3, permanentTiles[3], 0, new Vector3(0.5f, 0.0f, 0.91f));	// Stoop
		tiles[entranceStartingX, entranceStartingZ].GetComponent<Tile>().SetFloor(1);
		tiles[entranceStartingX, entranceStartingZ - 1].GetComponent<Tile>().SetFloor(1);
		tiles[entranceStartingX, entranceStartingZ - 2].GetComponent<Tile>().SetFloor(1);
		tiles[entranceStartingX, entranceStartingZ - 3].GetComponent<Tile>().SetFloor(1);

		// Load Upstairs Landing
		PlaceTile(upstairsStartingX, upstairsStartingZ, permanentTiles[4]);
		tiles[upstairsStartingX, upstairsStartingZ].GetComponent<Tile>().SetFloor(2);

		// Load Basement Landing
		PlaceTile(basementStartingX, basementStartingZ, permanentTiles[5]);
		tiles[basementStartingX, basementStartingZ].GetComponent<Tile>().SetFloor(0);

		// Camera starts at Entrance (for now)
		SendCamToLocation("entrance");

		tileDrawPile = new Stack<GameObject>();

		//setTransparent(testTile, true);
		System.Random _rnd = new System.Random();
		int _index;
		while (startingTilePile.Count > 0)
		{
			_index = _rnd.Next(startingTilePile.Count);
			tileDrawPile.Push(startingTilePile[_index]);
			startingTilePile.RemoveAt(_index);
		}
		UpdateCamPositioning();
		settingUpBoard = false;
		Highlight.highlightAvailableTiles = false;

		// Instantiate our player
		//players[1] = availablePlayers[0];	// Setting this up manually.  In the future, it can be chosen.
		players[1] = Instantiate(availablePlayers[0], new Vector3(entranceStartingX, 0.8f, entranceStartingZ - 2), Quaternion.Euler(Vector3.zero));
		players[1].GetComponent<Player>().setPosition(entranceStartingX, entranceStartingZ - 2);	// And now update the player's stored position.
		currentPlayer = 1;		// Our current player
	}
	/// <summary>
	/// Update().  Runs every frame.
	/// </summary>
	private void Update()
	{	
		ray = cam.ScreenPointToRay(Input.mousePosition);
		if (Physics.Raycast(ray, out rcHit))
		{
			Transform objectHit = rcHit.transform;
			curX = (int)Math.Floor(rcHit.point.x);
			curZ = (int)Math.Floor(rcHit.point.z);
		}

		// Move cam with keys
		bool camChangeMade = false;
		if (Input.GetKey(KeyCode.RightArrow))
		{
			camChangeMade = true;
			cam.transform.Translate(new Vector3(cameraSpeed * Time.deltaTime, 0, 0));
		}
		if (Input.GetKey(KeyCode.LeftArrow))
		{
			camChangeMade = true;
			cam.transform.Translate(new Vector3(-cameraSpeed * Time.deltaTime, 0, 0));
		}
		if (Input.GetKey(KeyCode.UpArrow))
		{
			camChangeMade = true;
			cam.transform.Translate(new Vector3(0, cameraSpeed * Time.deltaTime, 0));
		}
		if (Input.GetKey(KeyCode.DownArrow))
		{
			camChangeMade = true;
			cam.transform.Translate(new Vector3(0, -cameraSpeed * Time.deltaTime, 0));
		}
		if (camChangeMade)
		{
			// Only hit this if a change has been made.  Saves on frame updates.
			UpdateCamPositioning();
		}


		//if the player selects the " key, then set the activity to "moving player" so that highlighting tiles will work
		if (Input.GetKeyDown (KeyCode.M)) {
			SetActivity ("moving player");
			HighlightTilePlayerCanMove (); 

		}

		//when tiles that the player can move to are highlighted green and the player can move around
		if (SeeActivity().ToLower() == "moving player")
		{
			if (outlinesSet == false)
			{
				outlinesSet = true;
				getMovableTiles();
				outlineMovableTiles();
			}
		}
		return;
		if (SeeActivity ().ToLower()  == "moving player") {
			if (Input.GetMouseButtonDown (0)) {

				Plane playerPlane = new Plane (Vector3.up, transform.position + new Vector3(0f,.8f,0f)); 		//the plane of which the player will be moving about
				Ray ray = Camera.main.ScreenPointToRay (Input.mousePosition); 									//get the position of the mouse to move the player to
				float hitdist = 0.0f; 

				if (playerPlane.Raycast (ray, out hitdist)) {

					Vector3 targetPoint = ray.GetPoint (hitdist); 												//get the target position of where the mouse just clicked

					//foreach (Vector3 moveTile in tilesToMove) {
					foreach (KeyValuePair<Tile, Vector3> moveTile in Highlight.tileDict) {

						//if the player clicked on a tile they can move to
						if ((Math.Round (targetPoint.x) == moveTile.Value.x) && (Math.Round (targetPoint.z) == moveTile.Value.z)) {

							//move the player to that location
							player.transform.position = new Vector3 ((float)((Math.Round(targetPoint.x)) + 0.5 ), (float)0.8, (float)((Math.Round(targetPoint.z)) + 0.5)); 
							playerPos = player.transform.position; 


							tilesToMove.Clear();
							Highlight.highlightAvailableTiles = false; 
							SetActivity ("placing tile"); 

						} else {
							//they clicked on a space that was outside the range of the tiles they could move to
							Debug.Log ("can't move here"); 
						}

					}

				}
			}

		}

		//key code to go back to placing tiles
		if (Input.GetKeyDown (KeyCode.P)) {
			
			Highlight.highlightAvailableTiles = false; 
			SetActivity ("placing tile"); 
		}
		//this is probably not needed, but just for good measure, set an activity for when the spacebar is selected
		if (Input.GetKeyDown(KeyCode.Space))
			SetActivity("zoom");

		// Prints tiles[,] to file for debugging purposes.
		if (Input.GetKeyDown(KeyCode.D))
		{
			string output = "";
			Tile _tile;
			bool _N, _E, _S, _W;
			output = "Current tile: " + curX + ", " + curZ + System.Environment.NewLine;
			output += "     " + curX + "," + (curZ + 1) + System.Environment.NewLine;
			output += (curX - 1) + "," + curZ + "     " + (curX + 1) + "," + curZ + System.Environment.NewLine;
			output += "     " + curX + "," + (curZ - 1) + System.Environment.NewLine;
			for (int a = 0; a < tiles.GetLength(0); a++)
			{
				for (int b = 0; b < tiles.GetLength(1); b++)
				{
					if (tiles[a, b] != null)
					{
						_tile = tiles[a, b].GetComponent<Tile>();
						_N = _tile.doorN;
						_E = _tile.doorE;
						_S = _tile.doorS;
						_W = _tile.doorW;
						int _floor = _tile.currentFloor;
						output += "tiles[" + a + "," + b + "]:";
						output += " N:" + _N;
						output += " E:" + _E;
						output += " S:" + _S;
						output += " W:" + _W;
						output += " F:" + _floor + System.Environment.NewLine;
					}
				}
			}
			System.IO.File.WriteAllText(@"C:\Users\Public\debug.txt", output);
		}

		//go back to main menu
		if (Input.GetKeyDown(KeyCode.Q))
		{
			//Application.LoadLevel("MainMenu");
			SceneManager.LoadScene("MainMenu");
		}
		// We're placing a tile.
		if (SeeActivity().ToLower() == "placing tile")
		{
			float _height = tilesStart + floatingHeight;
			if (tmpTile == null)
			{
				tmpTile = Instantiate(tileDrawPile.Peek(), new Vector3(curX + 0.5f, _height, curZ + 0.5f), Quaternion.Euler(0.0f, tileDrawPile.Peek().GetComponent<Tile>().direction, 0.0f));
				UpdatePreview();
				tmpTileChangeMade = true;
			}
			if (oldX != curX || oldZ != curZ)
			{
				oldX = curX;    // Save to detect changes.  Don't want to update every frame, only when something has changed.
				oldZ = curZ;
				tmpTile.transform.position = new Vector3(curX + 0.5f, _height, curZ + 0.5f);
				setTransparent(tmpTile, true);
				tmpTileChangeMade = true;
			}
			if (Input.GetMouseButtonDown(1))
			{
				tmpTile.GetComponent<Tile>().RotateCW();
				tmpTileChangeMade = true;
			}
			if (Input.GetMouseButtonDown(0))
			{
				
				//tiles[curX, curZ] = tmpTile;
				if (CheckTilePlacement())
				{
					
					PlaceTile(curX, curZ, tmpTile, tmpTile.GetComponent<Tile>().direction);
					PlayerFollowTile ((float)curX, (float)0.8, (float)curZ); 										//Ro added this so player can follow tile placement
					Tile _debugTile = tiles[curX, curZ].GetComponent<Tile>();
					Highlight.tileDict.Add (_debugTile, (new Vector3 ((float)curX, (float)0.0, (float)curZ)));		//Ro added this: store the tile placed in a dictionary to use later for comparison
					tileDrawPile.Pop();
					Destroy(tmpTile);
					//redrawTiles();

				}
			}


			if (tmpTileChangeMade)
			{
				tmpTileChangeMade = false;
				if (CheckTilePlacement())
				{
					setRed(false);
					setTransparent(tmpTile);
				}
				else
				{
					setRed();
					setTransparent(tmpTile);
				}
				Tile _tile = tmpTile.GetComponent<Tile>();
				doorNorth.isOn = _tile.doorN;
				doorEast.isOn = _tile.doorE;
				doorSouth.isOn = _tile.doorS;
				doorWest.isOn = _tile.doorW;
				usableUpstairs.isOn = _tile.usableOnUpper;
				usableOnGroundFloor.isOn = _tile.usableOnGround;
				usableInBasement.isOn = _tile.usableInBasement;
			}
		}
	}
	/// <summary>
	/// Get all possible tiles a player can move to.
	/// </summary>
	public void getMovableTiles()
	{
		Player _player = players[currentPlayer].GetComponent<Player>();			// Current player
		int speed = players[currentPlayer].GetComponent<Player>().getSpeed();	// Player's speed
		moveOne(new Coord(_player.x, _player.z), speed);						// Start our decent into madness
	}
	/// <summary>
	/// Outline all tiles found in "getMovableTiles()"
	/// </summary>
	public void outlineMovableTiles()
	{
		foreach (Coord coord in availableMoves)
		{
			makeOutline(coord.x, coord.z);
		}
	}
	/// <summary>
	/// Recursive function that will move to all possible tiles a player can move to.
	/// </summary>
	/// <param name="c"></param>
	/// <param name="speedRemaining"></param>
	public void moveOne(Coord c, int speedRemaining)
	{
		string tileName = "null";
		if (tiles[c.x, c.z] != null)
			tileName = tiles[c.x, c.z].GetComponent<Tile>().roomName;

		if (!existsInList(c, availableMoves))
		{
			tileName = "null";
			if (tiles[c.x, c.z] != null)
				tileName = tiles[c.x, c.z].GetComponent<Tile>().roomName;
			availableMoves.Add(c);
		}
		int x = c.x;
		int z = c.z;
		if (tiles[x, z] == null)
			return;
		Tile thisTile = tiles[x, z].GetComponent<Tile>();
		foreach (string dir in new List<string> { "n", "e", "s", "w" })
		{
			int newX = x;
			int newZ = z;
			switch (dir)
			{
				case "n":
					if (!thisTile.doorN)
						continue;
					newZ++;
					break;
				case "e":
					if (!thisTile.doorE)
						continue;
					newX++;
					break;
				case "s":
					if (!thisTile.doorS)
						continue;
					newZ--;
					break;
				case "w":
					if (!thisTile.doorW)
						continue;
					newX--;
					break;
			}
			if (speedRemaining > 0)
				moveOne(new Coord(newX, newZ), speedRemaining - 1);
			else
				return;
		}
		foreach (GameObject go in thisTile.specialMoves)
		{
			string specialName = go.GetComponent<Tile>().roomName;
			for (int _x = 0; _x < 100; _x++)
			{
				for (int _z = 0; _z < 100; _z++)
				{
					if (tiles[_x, _z] != null && tiles[_x, _z].GetComponent<Tile>().roomName == specialName) {
						moveOne(new Coord(_x, _z), speedRemaining - 1);
					}
				}
			}
		}
		return;
	}
	/// <summary>
	/// Does the current tile already exist in the list?
	/// </summary>
	/// <param name="coord"></param>
	/// <param name="list"></param>
	/// <returns></returns>
	public bool existsInList(Coord coord, List<Coord> list)
	{
		foreach (Coord c in list)
		{
			if (coord.x == c.x && coord.z == c.z)
				return true;
		}
		return false;
	}
	/// <summary>
	/// Update the tile preview in the TL corner
	/// </summary>
	public void UpdatePreview()
	{
		//UITilePreview. = tmpTile.GetComponent<Renderer>().material.GetTexture()
		TilePreview.texture = tmpTile.GetComponent<Renderer>().material.mainTexture;
		//TilePreview.transform.eulerAngles = new Vector3(0.0f, 90.0f, 0.0f); //Rotate(90.0f, 0.0f, 0.0f);
		
		// This is the good rotation, but we don't want a rotatae.
		//TilePreview.transform.Rotate(0.0f, 0.0f, -90.0f); //Rotate(90.0f, 0.0f, 0.0f);
	}

	/// <summary>
	/// Set transparency of a tile.
	/// </summary>
	/// <param name="tile">The tile to change alpha channel</param>
	/// <param name="transparent">boolean to enable/disable transparency</param>
	private void setTransparent(GameObject tile, bool transparent = true)
	{
		//Debug.Log("Setting transparency.");
		Renderer rend = tile.GetComponent<Renderer>();
		Color oldColor = rend.material.color;
		float newAlpha;
		if (transparent)
		{
			//Debug.Log("Transparent.");
			newAlpha = transparentAlpha;
		}
		else
		{
			//Debug.Log("Not transparent.");
			newAlpha = 1.0f;
		}
		//testTile.GetComponent<Renderer>().material.SetColor("_Color", Color.red);
		//Debug.Log("New alpha: " + newAlpha.ToString());
		rend.material.color = new Color(oldColor.r, oldColor.b, oldColor.g, newAlpha);
	}
	/// <summary>
	/// Set the color of a tile Red (Can't move there)
	/// </summary>
	/// <param name="tile">The tile</param>
	/// <param name="makeRed">true/false for enable/disable respectively</param>
	private void setRed(GameObject tile, bool makeRed = true)
	{
		Color newColor;
		if (makeRed)
			newColor = Color.red;
		else
			newColor = Color.white;
		tile.GetComponent<Renderer>().material.SetColor("_Color", newColor);
	}
	private void setRed(bool makeRed = true)
	{
		Tile tile = tmpTile.GetComponent<Tile>();
		Color newColor;
		if (makeRed)
			newColor = Color.red;
		else
			newColor = Color.white;
		tile.GetComponent<Renderer>().material.SetColor("_Color", newColor);
	}
	public void UpdateCamPositioning()
	{
		// Reset height
		cam.transform.position = new Vector3(cam.transform.position.x, cameraHeight, cam.transform.position.z);

		// Reset pitch/yaw
		cam.transform.eulerAngles = new Vector3(cameraPitchAngle, cameraYawAngle, 0.0f);
	}
	/// <summary>
	/// Check to see if the current spot can accomodate the current tile in its position.
	/// </summary>
	/// <returns></returns>
	private bool CheckTilePlacement()
	{
		GameObject tileN = tiles[curX, curZ + 1];		// Tile to the NORTH
		GameObject tileS = tiles[curX, curZ - 1];		// South
		GameObject tileE = tiles[curX + 1, curZ];		// East
		GameObject tileW = tiles[curX - 1, curZ];		// West

		Tile tileNScript = null;						// Need to check the doors, so first grab the scripts.
		Tile tileEScript = null;
		Tile tileSScript = null;
		Tile tileWScript = null;
		if (tileN != null)
			tileNScript = tileN.GetComponent<Tile>();
		if (tileE != null)
			tileEScript = tileE.GetComponent<Tile>();
		if (tileS != null)
			tileSScript = tileS.GetComponent<Tile>();
		if (tileW != null)
			tileWScript = tileW.GetComponent<Tile>();

		Tile tile = tmpTile.GetComponent<Tile>();       // Our currently held tile

		if (TileOccupied())
		{
			if (tilePlacementDebug)
				Debug.Log("Can't place tile: occupied.");
			return false;
		}

		if (AllAdjacentTilesEmpty())
		{
			if (tilePlacementDebug)
				Debug.Log("Can't place tile: Not adjacent to any tiles.");
			return false;
		}

		// Any non-matching doors?
		bool hasOneMatch = false;
		foreach (string dir in new List<string> { "n", "e", "s", "w" })
		{
			bool isDoor = tile.GetDoor(dir);
			bool tileNull = TileIsNull(dir);
			bool tileHasDoor = TileHasDoor(dir);
			if (dir == "w" && debugging)
			{
				bool testBool = true;
			}
			if (tile.GetDoor(dir) && !TileIsNull(dir) && !TileHasDoor(dir))
			{
				if (tilePlacementDebug)
					Debug.Log("Can't place tile: Directional door unavailable.");
				return false;
			}
			if (!tile.GetDoor(dir) && !TileIsNull(dir) && TileHasDoor(dir))
			{
				if (tilePlacementDebug)
					Debug.Log("Can't place tile: No door to match directional door.");
				return false;
			}
			if (tile.GetDoor(dir) && !TileIsNull(dir) && TileHasDoor(dir))
				hasOneMatch = true;
		}
		if (!hasOneMatch)
		{
			if (tilePlacementDebug)
				Debug.Log("Can't place tile: At least one door must match up.");
			return false;
		}

		if (!PlayableOnFloor())
		{
			if (tilePlacementDebug)
				Debug.Log("Not playable on this floor.");
			return false;
		}

		if (tilePlacementDebug)
			Debug.Log("Tile may be placed here.");
		return true;
	}
	/// <summary>
	/// Is the tile playable on this floor?
	/// </summary>
	/// <returns></returns>
	private bool PlayableOnFloor()
	{
		int floor = GetFloor();
		if (floor == -1)
			Debug.Log("What in the hell?");
		Tile tile = tmpTile.GetComponent<Tile>();
		if (floor == 0 && tile.usableInBasement)
			return true;
		if (floor == 1 && tile.usableOnGround)
			return true;
		if (floor == 2 && tile.usableOnUpper)
			return true;
		return false;
	}
	/// <summary>
	/// Is the current tile occupied?
	/// </summary>
	/// <param name="x"></param>
	/// <param name="z"></param>
	/// <returns></returns>
	private bool TileOccupied(int x, int z)
	{
		if (tiles[x, z] != null)
			return true;
		return false;
	}
	/// <summary>
	/// Is the current tile occupied?
	/// </summary>
	/// <returns></returns>
	private bool TileOccupied()
	{
		return TileOccupied(curX, curZ);
	}
	/// <summary>
	/// Are all adjacent tiles empty?
	/// </summary>
	/// <param name="x"></param>
	/// <param name="z"></param>
	/// <returns></returns>
	private bool AllAdjacentTilesEmpty(int x, int z)
	{
		GameObject tileN = tiles[curX, curZ + 1];       // Tile to the NORTH
		GameObject tileS = tiles[curX, curZ - 1];       // South
		GameObject tileE = tiles[curX + 1, curZ];       // East
		GameObject tileW = tiles[curX - 1, curZ];       // West
		if (tileN == null && tileS == null && tileE == null && tileW == null)   // Are adjacent tiles all empty?  If so, can't place there.
			return true;
		return false;
	}
	/// <summary>
	/// Are all adjacent tiles empty?
	/// </summary>
	/// <returns></returns>
	private bool AllAdjacentTilesEmpty()
	{
		return AllAdjacentTilesEmpty(curX, curZ);
	}
	/// <summary>
	/// Does the direction tile have an appropriate door?
	/// </summary>
	/// <param name="dir"></param>
	/// <returns></returns>
	private bool TileHasDoor(string dir)
	{
		dir = dir.ToLower();
		if (debugging && dir == "w")
			Debug.Log("Break");
		int x = curX;
		int z = curZ;
		if (dir == "n")
			z++;
		if (dir == "e")
			x++;
		if (dir == "s")
			z--;
		if (dir == "w")
			x--;
		if (tiles[x, z] == null)
			return false;
		Tile testTile = tiles[x, z].GetComponent<Tile>();
		if (dir == "n")
			return testTile.doorS;
		if (dir == "e")
			return testTile.doorW;
		if (dir == "s")
			return testTile.doorN;
		if (dir == "w")
			return testTile.doorE;
		//Debug.Log("You should not EVER get here.");
		return false;
	}
	/// <summary>
	/// Is the directional tile null?
	/// </summary>
	/// <param name="dir"></param>
	/// <returns></returns>
	private bool TileIsNull(string dir)
	{
		return TileIsNull(dir, curX, curZ);
	}
	private bool TileIsNull(string dir, int x, int z)
	{
		dir = dir.ToLower();
		if (dir == "n")
			z++;
		if (dir == "e")
			x++;
		if (dir == "s")
			z--;
		if (dir == "w")
			x--;
		if (tiles[x, z] == null)
			return true;
		return false;
	}
	/// <summary>
	/// Place selected tile onto the game board.
	/// </summary>
	/// <param name="x">X-Coordinate</param>
	/// <param name="z">Z-Coordinate</param>
	/// <param name="tile">Tile to place</param>
	public void PlaceTile(int x, int z, GameObject tile)
	{
		PlaceTile(x, z, tile, 180.0f, new Vector3(0.5f, 0.0f, 0.5f));
	}
	/// <summary>
	/// Place selected tile onto the game board.
	/// </summary>
	/// <param name="x">X-Coordinate</param>
	/// <param name="z">Z-Coordinate</param>
	/// <param name="tile">Tile to place</param>
	/// <param name="rotation">Direction to place the tile in degrees</param>
	public void PlaceTile(int x, int z, GameObject tile, int rotation)
	{
		PlaceTile(x, z, tile, (float)rotation);
	}
	/// <summary>
	/// Place selected tile onto the game board.
	/// </summary>
	/// <param name="x">X-Coordinate</param>
	/// <param name="z">Z-Coordinate</param>
	/// <param name="tile">Tile to place</param>
	/// <param name="rotation">Direction to place the tile in degrees</param>
	public void PlaceTile(int x, int z, GameObject tile, float rotation)
	{
		PlaceTile(x, z, tile, rotation, new Vector3(0.5f, 0.0f, 0.5f));
	}
	/// <summary>
	/// Place selected tile onto the game board.
	/// </summary>
	/// <param name="x">X-Coordinate</param>
	/// <param name="z">Z-Coordinate</param>
	/// <param name="tile">Tile to place</param>
	/// <param name="rotation">Direction to place the tile in degrees</param>
	/// <param name="offset">Tile offset</param>
	public void PlaceTile(int x, int z, GameObject tile, int rotation, Vector3 offset)
	{
		PlaceTile(x, z, tile, (float)rotation, offset);
	}
	/// <summary>
	/// Place selected tile onto the game board.
	/// </summary>
	/// <param name="x">X-Coordinate</param>
	/// <param name="z">Z-Coordinate</param>
	/// <param name="tile">Tile to place</param>
	/// <param name="rotation">Direction to place the tile in degrees</param>
	/// <param name="offset">Tile offset</param>
	public void PlaceTile(int x, int z, GameObject tile, float rotation, Vector3 offset)
	{
		float newX = x + offset.x;
		float newZ = z + offset.z;
		float height = tilesStart + tileHeight;
		tiles[x, z] = Instantiate(tile, new Vector3(newX, height, newZ), Quaternion.Euler(0.0f, rotation, 0.0f));
		Tile _debugTmp = tiles[x, z].GetComponent<Tile>();
		//tiles[x, z].GetComponent<Tile>() = tmpTile.GetComponent<Tile>();
		if (!settingUpBoard)
		{
			tiles[x, z].GetComponent<Tile>().Import(tmpTile);
			tiles[x, z].GetComponent<Tile>().SetFloor(GetFloor());
		}
		tiles[x, z].GetComponent<Tile>().displayed = true;
		setRed(tiles[x, z], false);
		setTransparent(tiles[x, z], false);
		/*for (int a = (int)rotation; a >= 0; a -= 90)
		{
			tiles[x, z].GetComponent<Tile>().ShiftDoorsCW();
		}*/
	}
	/// <summary>
	/// Get the floor of the adjacent tiles.
	/// </summary>
	/// <returns></returns>
	private int GetFloor()
	{
		foreach (string dir in new List<string> { "n", "e", "s", "w" })
		{
			int x = curX;
			int z = curZ;
			if (dir == "n")
				z++;
			if (dir == "e")
				x++;
			if (dir == "s")
				z--;
			if (dir == "w")
				x--;
			if (tiles[x, z] != null)
			{
				Tile tile = tiles[x, z].GetComponent<Tile>();
				Tile _tmpTileScript = tmpTile.GetComponent<Tile>();

				// Just for debugging purposes
				bool _GetDoor = _tmpTileScript.GetDoor(dir);
				bool _TileIsNull = TileIsNull(dir);
				bool _TileHasDoor = TileHasDoor(dir);
				// Just for debugging purposes

				//if (tile.GetDoor(dir) && !TileIsNull(dir) && TileHasDoor(dir))
				if (_tmpTileScript.GetDoor(dir) && !TileIsNull(dir) && TileHasDoor(dir))
					return tile.currentFloor;
			}
		}
		return -1;
	}
	/// <summary>
	/// Set the current player activity
	/// </summary>
	/// <param name="act">The activity to set</param>
	public void SetActivity(string act)
	{
		activity.Push(act);
		if (act == "placing tiles")
		{
			oldX = -1;
			oldZ = -1;
		}
	}
	/// <summary>
	/// See what the current activity is.  Uses Peek() and not Pop()
	/// </summary>
	/// <returns>The activity currently taking place</returns>
	public string SeeActivity()
	{
		string currentActivity = "";
		try
		{
			currentActivity = activity.Peek();
		}catch(System.InvalidOperationException e)
		{
			return "";
		}
		return currentActivity;
	}
	/// <summary>
	/// Pop() the current activity and return to the previous one.
	/// </summary>
	/// <returns></returns>
	public string ReturnToPreviousActivity()
	{
		string previousActivity = "";
		try
		{
			previousActivity = activity.Pop();
		}
		catch(System.InvalidOperationException e)
		{
			return "";
		}
		if (previousActivity == "placing tiles")
		{
			oldX = -1;
			oldZ = -1;
		}
		return previousActivity;
	}
	/// <summary>
	/// Roll the dice.
	/// </summary>
	/// <param name="numberOfDice"></param>
	/// <returns></returns>
	public int RollDice(int numberOfDice)
	{
		System.Random _rnd = new System.Random();
		int _total = 0;
		for (int a = 0; a < numberOfDice; a++)
		{
			_total += _rnd.Next(3);
		}

		return _total;
	}
	public int RollDice(Player player)
	{
		return RollDice(player.getSpeed());
	}
	/// <summary>
	/// Sends camera to one of the initial floor locations.
	/// </summary>
	/// <param name="location"></param>
	public void SendCamToLocation(string location)
	{
		//Debug.Log("Going " + location);
		//Debug.Log(upstairsStartingX + " " + upstairsStartingZ);
		location = location.ToLower();
		int x = 0;
		int z = 0;
		if (location == "ground" || location == "entrance")
		{
			x = entranceStartingX;
			z = entranceStartingZ;
		} else if (location == "upper" || location == "upstairs")
		{
			x = upstairsStartingX;
			z = upstairsStartingZ;
		}else if (location == "basement")
		{
			x = basementStartingX;
			z = basementStartingZ;
		}
		//Debug.Log("New Camera X: " + x);
		//Debug.Log("New Camear Y: " + z);
		cam.transform.position = tiles[x, z].transform.position;
		cam.transform.Translate(new Vector3(0f, 0f, cameraOffset));
		UpdateCamPositioning();
	}

	/// <summary>
	/// Make player land on the most recently placed tile.
	/// </summary>
	/// <param name="x"></param>
	/// <param name="y"></param>
	/// <param name="z"></param>
	public void PlayerFollowTile(float x, float y, float z){
		
		player.transform.position = new Vector3((float)(x + 0.5), (y), (float)(z + 0.5)); 		//changes the player's current position to the new position on the board, recent tile
		playerPos = player.transform.position; 													//sets that position, player is in new position
		Debug.Log ("player position: " + playerPos); 
	}

	/* =========== FUNCTION: to highlight specific tiles the player can move to ===========*/
	public void HighlightTilePlayerCanMove(){

		Highlight.tilesToHighlight.Clear (); 
		Highlight.highlightAvailableTiles = true;												//flag to let us know we can highlight specified tiles 
		Debug.Log("===================== HIGH LIGHT ======================"); 
		/*=========== INITIALIZE VARIABLES =============*/
		Vector3 newItemPositiveX = new Vector3(0,0,0); 											//to get the positive new x positions
		Vector3 newItemNegativeX = new Vector3(0,0,0); 											//to get the negative new x positions
		Vector3 newPositionX = new Vector3 ((float)4.0, (float)0.0, (float)0.0); 				//this will establish our range

		Vector3 newItemPositiveZ = new Vector3(0,0,0); 											//to get the positive new z positions
		Vector3 newItemNegativeZ = new Vector3(0,0,0); 											//to get the negative new z positions
		Vector3 newPositionZ = new Vector3 ((float)0.0, (float)0.0, (float)4.0); 				//this will establish our range

		//this will give us a position to compare so that we don't highlight the tile the player is currently on
		Vector3 playerPosToCompare = new Vector3((float)(playerPos.x - 0.5), (float)0.0, (float)(playerPos.z - 0.5)); 
		bool door = false; 

		//FOR DEBUGGING
		//Debug.Log ("dictionary count: " + Highlight.tileDict.Count); 
		//Debug.Log("highlight tiles count when we first start the method: " + Highlight.tilesToHighlight.Count); 

		//if (Highlight.tilesToHighlight.Count >= 0) {
		//	foreach (Tile tth in Highlight.tilesToHighlight) {
		//		Debug.Log ("tth: " + tth); 
		//		Highlight.tilesToHighlight.Remove (tth); 
		//	}
		//}





		//iterate through the dicitonary
		foreach (KeyValuePair<Tile, Vector3> newTile in Highlight.tileDict) {
			//Debug.Log ("newTile in dictionary: " + newTile); 

			//get the positions of all the tiles in the dictionary
			newItemPositiveX = newTile.Value; 
			newItemNegativeX = newTile.Value; 
			newItemPositiveZ = newTile.Value; 
			newItemNegativeZ = newTile.Value; 

			//create our x-range
			newItemPositiveX = newItemPositiveX + newPositionX; 
			newItemNegativeX = newItemNegativeX - newPositionX; 

			//create our z-range
			newItemPositiveZ = newItemPositiveZ + newPositionZ; 
			newItemNegativeZ = newItemNegativeZ - newPositionZ; 
			curX = (int)newTile.Value.x; 
			curZ = (int)newTile.Value.z; 

			foreach (string dir in new List<string> { "n", "e", "s", "w" }) {
				if (TileHasDoor (dir)) {
					door = true; 
					break; 
				} else {
					door = false; 
				} 
			}
		
			if ((playerPosToCompare.x <= newItemPositiveX.x) && (playerPosToCompare.x >= newItemNegativeX.x) && (playerPosToCompare.z <= newItemPositiveZ.z) && (playerPosToCompare.z >= newItemNegativeZ.z) &&  (playerPosToCompare != newTile.Value)) {
				//add those tiles to a list that our PlayerTileHighlight script is going to access and then highlight those tiles green


				Debug.Log ("TILE WE CAN HIGHLIGHT: " + newTile); 
				Debug.Log ("player pos: " + playerPosToCompare); 

				Highlight.tilesToHighlight.Add (newTile.Key);
				tilesToMove.Add (newTile.Value); 
				//move.Add (newTile.Key, newTile.Value); 

				Debug.Log ("Tiles to highlight count at end of function: " + Highlight.tilesToHighlight.Count);

			} else {

				Debug.Log ("TILE WE CAN'T HIGHLIGHT!!!! " + newTile); 
				//Highlight.tilesToNotHighlight.Add(newTile.Key); 
				continue; 

			}

		}

		Debug.Log ("Tiles to highlight count at end of function: " + Highlight.tilesToHighlight.Count);


	}
	/// <summary>
	/// Create a highlight color around the specified tile.
	/// </summary>
	/// <param name="x"></param>
	/// <param name="z"></param>
	public void makeOutline(int x, int z)
	{
		//GameObject highlight = Instantiate(outline, tiles[x, z].transform.position, Quaternion.Euler(Vector3.zero));
		float _x = x + 0.5f;
		float _y = highlightY;
		float _z = z + 0.5f;
		//GameObject highlight = Instantiate(outline, new Vector3(_x, _y, _z), Quaternion.Euler(Vector3.zero));
		outlines.Add(Instantiate(outline, new Vector3(_x, _y, _z), Quaternion.Euler(Vector3.zero)));
	}
	public void makeOutline(int x, int z, string color)
	{
		makeOutline(x, z);
		colorOutlines(color);
	}
	/// <summary>
	/// Set outline color
	/// </summary>
	/// <param name="color"></param>
	public void colorOutlines(Color color)
	{
		foreach (GameObject outline in outlines)
		{
			foreach (var child in outline.GetComponentsInChildren<Renderer>())
			{
				if (child.transform != transform)
				{
					child.material.color = color;
				}
			}
		}
	}
	public void colorOutlines(string color)
	{
		color = color.ToLower();
		Color c;
		c = Color.white;
		switch (color)
		{
			case "red":
				c = Color.red;
				break;
			case "white":
				c = Color.white;
				break;
			case "black":
				c = Color.black;
				break;
			case "blue":
				c = Color.blue;
				break;
			case "cyan":
				c = Color.cyan;
				break;
			case "grey":
			case "gray":
				c = Color.gray;
				break;
			case "magenta":
				c = Color.magenta;
				break;
			case "yellow":
				c = Color.yellow;
				break;
			default:
				c = Color.white;
				break;
		}
		colorOutlines(c);
	}
	public void removeOutlines()
	{
		while (outlines.Count > 0)
		{
			Destroy(outlines[0]);
			outlines.RemoveAt(0);
		}
	}
}